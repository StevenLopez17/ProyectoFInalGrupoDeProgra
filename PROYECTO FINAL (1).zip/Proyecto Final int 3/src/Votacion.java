import javax.swing.*;
import java.util.Scanner;

public class Votacion {
    public static void main( String [] args ) {

        int voto;
        int totalFA = 0;
        int totalPSD = 0;
        int totalLN = 0;
        int totalLP = 0;
        int totalNulo = 0;
        int total;
        int respuesta;
        int votos = 0;

        do
        {
            Scanner leer = new Scanner (System.in);
            System.out.println("Bienvenido/a al sistema de votacion nacional. ");
            System.out.println("Porfavor siga las instrucciones al pie de la letra. ");
            String nombre= JOptionPane.showInputDialog(null, "Porfavor, digite su nombre completo: ");
            String cedula= JOptionPane.showInputDialog(null, "Porfavor, digite su numero de cedula: ");
            JOptionPane.showMessageDialog(null, "Bienvenido/a "+ nombre +" " + "de cedula numero " + cedula);
            System.out.println("Por quien desea votar:");
            System.out.println("Codigo\t"+"Nombre");
            System.out.println("1\t"+" Jose Maria Villalta Florez Estrada (Frente Amplio).");
            System.out.println("2\t"+" Rodrigo Alberto Chaves Robles (Progreso Social Democratico).");
            System.out.println("3\t"+" Jose Maria Figueres Olsen (Liberacion Nacional).");
            System.out.println("4\t"+" Eliécer Feinzaig Mintz (Liberal Progresista).");
            System.out.println("5\t"+" Voto Nulo");
            System.out.println("Ingrese el codigo de candidato por el que desea votar y seguidamente presione la tecla enter.");

            voto = leer.nextInt();
            votos = votos+1;

            switch (voto) {
                case 1 -> totalFA = totalFA + 1;
                case 2 -> totalPSD = totalPSD + 1;
                case 3 -> totalLN = totalLN + 1;
                case 4 -> totalLP = totalLP + 1;
                case 5 -> totalNulo = totalNulo + 1;
            }
            total= totalFA+totalPSD+totalLN+totalLP+totalNulo;
            JOptionPane.showMessageDialog(null, "Gracias por ejercer su voto "+ nombre);
            System.out.println("¿Desea continuar con la votacion?");
            System.out.println("1 = Si\t 2 = no");
            respuesta = leer.nextInt();

        }while (respuesta != 2);

        System.out.println("Nombre de candidato\t\t\t\t\t\t\t\t\t\t\t\t\tTotal Votos\t\t\t\tPorcentaje");
        System.out.println("Jose Maria Villalta Florez Estrada (Frente Amplio):\t\t\t\t\t\t"+totalFA+"\t\t\t\t\t\t"+((100/votos)*totalFA)+"%");
        System.out.println("Rodrigo Alberto Chaves Robles (Progreso Social Democratico):\t\t\t"+totalPSD+"\t\t\t\t\t\t"+((100/votos)*totalPSD)+"%");
        System.out.println("Jose Maria Figueres Olsen (Liberacion Nacional):\t\t\t\t\t\t"+totalLN+"\t\t\t\t\t\t"+((100/votos)*totalLN)+"%");
        System.out.println("Eliécer Feinzaig Mintz (Liberal Progresista):\t\t\t\t\t\t\t"+totalLP+"\t\t\t\t\t\t"+((100/votos)*totalLP)+"%");
        System.out.println("Voto Nulo:\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t"+totalNulo+"\t\t\t\t\t\t"+((100/votos)*totalNulo)+"%");
        System.out.println("Votos Totales:\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" + total);

    }
}
